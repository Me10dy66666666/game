package JFrame.ui;


public class App {
    public static void main(String[] args) {
        new LoginJFrame();
    }
}